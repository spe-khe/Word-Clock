#include "Clock.h"


// Constructor
Clock::Clock(bool manualSet)
{
    this->manualSet = manualSet;
}

// update local time from NTP server
void Clock::setNTPTime()
{
    // only update if the time isn't set manually
    if (!manualSet)
    {
        configTime(0, 0, "pool.ntp.org");
        struct tm timeinfo;
        
        getLocalTime(&timeinfo);

        //TODO: this should probably be moved to a .begin function, the timezone only has to be set once.
        setenv("TZ", "CET-1CEST,M3.5.0,M10.5.0/3", 1);
        tzset();

        if (getLocalTime(&timeinfo))
        {
            rtc.setTimeStruct(timeinfo);
        }
        // remember when the time was last updated
        updateTime = rtc.getEpoch();
    }
}

// increase the hour
void Clock::incHour()
{
    this->manualSet = true;
    long epoch = this->rtc.getEpoch();
    this->rtc.setTime(epoch + 3600);
}

// increase the minute
void Clock::incMinute()
{
    this->manualSet = true;
    long epoch = this->rtc.getEpoch();
    this->rtc.setTime(epoch + 60);
    // TODO: this should always jump to a full minute, so the clock can be set accurately
}

// Returns the current hour
int Clock::getHour()
{
    // if the time hasn't been updated in an hour, update it from the NTP server
    if (this->manualSet && this->rtc.getEpoch() - this->updateTime >= 3600)
    {
        this->setNTPTime();
    }

    return this->rtc.getHour();
}

// Returns the current minute
int Clock::getMinute()
{
    return this->rtc.getMinute();
}
