#ifndef SPE_CLOCK_OWM
#define SPE_CLOCK_OWM

#include <Arduino.h>
#include <HTTPClient.h>
#include <Arduino_JSON.h>
#include <string>
#include <string.h>
#include <sstream>

class OpenWeatherMap
{
private:
    // coordinates
    double lat = 0;
    double lon = 0;

    char *zipcode;

    char apiKey[33] = "";

    // for buffering the server response
    String jsonBuffer;

    // millis() value at the last update time
    unsigned long int lastUpdate = 0;

    // received values
    int temperature;
    int humidity;

public:
    /// @brief Constructor
    OpenWeatherMap();

    /// @brief Set the OpenWeatherMap API key
    /// @param apiKey OpenWeatherMap API key
    void setAPIKey(const char *apiKey);

    /// @brief Set the location by zip code
    /// @param zipCode zip code in format {zip code},{country code}
    void setByZipCode(const char *zipCode);

    /// @brief Checks if the location is set
    /// @return Whether the location is set
    bool locationIsSet();

    /// @brief Update the weather values - this does nothing if the last update was less than 30 s ago
    void update();

    /// @brief Get the received humidity
    /// @return the received humidity
    int getHumidity();

    /// @brief Get the received temperature
    /// @return the received temperature
    int getTemperature();
};

/// @brief send a HTTP Get Request to the given server URL
/// @param serverName server URL
/// @return response string
static String httpGETRequest(std::string serverName)
{
    WiFiClient client;
    HTTPClient http;

    http.begin(client, serverName.c_str()); // Your Domain name with URL path or IP address with path
    int httpResponseCode = http.GET();      // Send HTTP POST request
    String payload = "{}";

    if (httpResponseCode > 0)
    {
        payload = http.getString();
    }
    else
    {
        Serial.print("Error ");
    }
    http.end();
    return payload;
}

OpenWeatherMap::OpenWeatherMap()
{
}

inline void OpenWeatherMap::setAPIKey(const char *apiKey)
{
    // copy the passed api key into the class member
    strcpy(this->apiKey, apiKey);
}

inline void OpenWeatherMap::setByZipCode(const char *zipCode)
{
    if (apiKey != "")
    {
        // assemble the server path
        std::stringstream serverPath;
        serverPath << "http://api.openweathermap.org/geo/1.0/zip?zip=" << zipCode << "&appid=" << apiKey;

        // send the request
        jsonBuffer = httpGETRequest(serverPath.str());

        // parse the JSON response
        JSONVar myObject = JSON.parse(jsonBuffer);

        if (JSON.typeof(myObject) == "undefined")
        {
            Serial.println("Parsing input failed!");
            return;
        }

        // store the received values
        lat = isnan((double)myObject["lat"]) ? 0.0 : (double)myObject["lat"];
        lon = isnan((double)myObject["lon"]) ? 0.0 : (double)myObject["lon"];
    }
    else
    {
        strcpy(this->zipcode, zipCode);
    }
    
}

inline bool OpenWeatherMap::locationIsSet()
{
    return lat > 0 || lon > 0;
}


inline void OpenWeatherMap::update()
{
    // only update if the last update is less than 30 s ago
    if (apiKey != "" && millis() - lastUpdate > 30000)
    {
        lastUpdate = millis();

        if (!locationIsSet())
        {
            setByZipCode(this->zipcode);
        }
        

        // assemble the server path
        std::stringstream serverPath;
        serverPath << "http://api.openweathermap.org/data/2.5/weather?units=metric&lat=" << lat << "&lon=" << lon << "&appid=" << apiKey;

        // send the request
        jsonBuffer = httpGETRequest(serverPath.str());

        // parse the JSON response
        JSONVar myObject = JSON.parse(jsonBuffer);

        if (JSON.typeof(myObject) == "undefined")
        {
            Serial.println("Parsing input failed!");
            return;
        }
        // store the received values
        temperature = (int)myObject["main"]["temp"];
        humidity = (int)myObject["main"]["humidity"];
    }
}

inline int OpenWeatherMap::getHumidity()
{
    return humidity;
}

inline int OpenWeatherMap::getTemperature()
{
    return temperature;
}

#endif