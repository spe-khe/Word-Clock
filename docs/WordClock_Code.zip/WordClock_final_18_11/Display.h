#ifndef SPE_CLOCK_DISPL_H
#define SPE_CLOCK_DISPL_H

#define NUM_LEDS 114
#define NUM_COLS 11

#include <Arduino.h>
#include <FastLED.h>

/*
 * Section of a row of the matrix
 */
struct displayGroup
{
    int row;
    int start;
    int end;
    /// Constructor
    /// @param row row of the segment
    /// @param start start column
    /// @param end end column
    displayGroup(int row, int start, int end)
    {
        this->row = row;
        this->start = start;
        this->end = end;
    }
};

/************************************* Definition of display element coordinates **************************************/
const CRGB colors[] = {
    CRGB(255, 255, 255), // white
    CRGB(255, 0, 0),     // red
    CRGB(0, 255, 0),     // green
    CRGB(0, 0, 255),     // blue
    CRGB(255, 155, 0),   // yellow
    CRGB(0, 255, 255),   // cyan
    CRGB(138, 43, 226),  // violet
    CRGB(255, 0, 255)    // purple
};

// Hour words
const displayGroup displayNumbers[13] = {
    displayGroup(4, 6, 10), // 12
    displayGroup(5, 2, 5),  // 1
    displayGroup(5, 0, 3),  // 2
    displayGroup(6, 1, 4),  // 3
    displayGroup(8, 7, 10), // 4
    displayGroup(6, 6, 9),  // 5
    displayGroup(9, 1, 5),  // 6
    displayGroup(5, 5, 10), // 7
    displayGroup(7, 1, 4),  // 8
    displayGroup(8, 3, 6),  // 9
    displayGroup(7, 5, 8),  // 10
    displayGroup(8, 0, 2),   // 11
    displayGroup(4, 6, 10) // 12
};
// minute Words
const displayGroup displayWords[10] = {
    displayGroup(0, 0, 1),
    displayGroup(0, 3, 5),
    displayGroup(0, 7, 10),
    displayGroup(1, 0, 3),
    displayGroup(1, 4, 10),
    displayGroup(2, 1, 7),
    displayGroup(3, 1, 4),
    displayGroup(3, 7, 9),
    displayGroup(4, 0, 3),
    displayGroup(9, 7, 9)};
// minute word indices
enum displayWordIndices
{
    ES,
    IST,
    FUENF,
    ZEHN,
    VIERTEL,
    ZWANZIG,
    NACH,
    VOR,
    HALB,
    UHR
};

// pixel digits
const bool digits[][5][4] = {
    {
        {0, 1, 1, 0},
        {1, 0, 0, 1},
        {1, 0, 0, 1},
        {1, 0, 0, 1},
        {0, 1, 1, 0},
    },
    {
        {0, 1, 1, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0},
    },
    {
        {0, 1, 1, 0},
        {1, 0, 0, 1},
        {0, 0, 1, 0},
        {0, 1, 0, 0},
        {1, 1, 1, 1},
    },
    {
        {1, 1, 1, 1},
        {0, 0, 0, 1},
        {0, 1, 1, 1},
        {0, 0, 0, 1},
        {1, 1, 1, 1},
    },
    {
        {1, 0, 0, 1},
        {1, 0, 0, 1},
        {1, 1, 1, 1},
        {0, 0, 0, 1},
        {0, 0, 0, 1},
    },
    {
        {0, 1, 1, 1},
        {1, 0, 0, 0},
        {1, 1, 1, 1},
        {0, 0, 0, 1},
        {1, 1, 1, 1},
    },
    {
        {1, 1, 1, 1},
        {1, 0, 0, 0},
        {1, 1, 1, 1},
        {1, 0, 0, 1},
        {1, 1, 1, 1},
    },
    {
        {1, 1, 1, 1},
        {0, 0, 0, 1},
        {0, 0, 1, 0},
        {0, 1, 0, 0},
        {1, 0, 0, 0},
    },
    {
        {1, 1, 1, 1},
        {1, 0, 0, 1},
        {0, 1, 1, 0},
        {1, 0, 0, 1},
        {1, 1, 1, 1},
    },
    {
        {1, 1, 1, 1},
        {1, 0, 0, 1},
        {1, 1, 1, 1},
        {0, 0, 0, 1},
        {1, 1, 1, 1},
    }};

template <int dataPin>
class Display
{
private:
    // Display color at full brightness
    CRGB color;
    // Brightness Factor 0 <= factor <= 10
    int brightness = 5;
    // whether the clock is online
    bool online;
    // whether to set the brightness automatically
    bool autoBrightness = false;
    // last time the brightness was automatically adjusted
    unsigned long int lastAdjustTime = 0;
    // whether the clock is in "setting mode" -> the display is flashing
    bool settingMode;
    // index of the currently set color
    int colorIndex;

    // buffer object for the leds
    CRGB leds[NUM_LEDS];

    // pins to which the led strip and brightness sensor are connected
    int brightnessPin;

    // turn on a segment of leds
    void setLEDs(int row, int start, int end)
    {
        for (int i = start; i <= end; i++)
        {
            setLED(i, row);
        }
    };

    void setLEDs(const displayGroup displayObject)
    {
        setLEDs(displayObject.row, displayObject.start, displayObject.end);
    };

    // turn on a single LED
    void setLED(int x, int y)
    {
        // adjust brightness if the last time was more than 5s ago
        if (millis() - lastAdjustTime > 5000)
        {
            adjustBrightness();
            lastAdjustTime = millis();
        }
        
        // if settingMode is on, blink all the LEDs (alternate brightness)
        int set_brightness;
        if (settingMode)
        {
            bool on = (millis() % 500) > 250;
            set_brightness = brightness * (int)on;
        }
        else
        {
            set_brightness = brightness;
        }

        // calculate LED number in the string
        int row_offset = y * NUM_COLS;
        int col_offset;
        if (y % 2)
        {
            // odd row -> LEDs are routed right to left
            col_offset = NUM_COLS - 1 - x;
        }
        else
        {
            // even row -> LEDs are routed left to right
            col_offset = x;
        }

        // turn on the calculated LED
        CRGB sel_color = colors[colorIndex];
        sel_color.nscale8(256.0 * ((double)(set_brightness) / 10.0) * ((double)(set_brightness) / 10.0));
        leds[row_offset + col_offset] = sel_color;
#ifdef virtual
        // print debug info if there is no hardware for testing
        Serial.print(x);
        Serial.print("x");
        Serial.print(y);
        Serial.print("->");
        Serial.println(row_offset + col_offset);
#endif
    };
    // turn on the status LEDs according to the status bools
    void displayStatus()
    {
        if (autoBrightness)
        {
            setLED(0, 9);
        }
        if (!online)
        {
            setLED(10, 9);
        }
    };

    // display a number in a 4x5 grid at the given location using the leds as pixels
    void displayDigit(int digit, int originX, int originY)
    {
        if (digit <= 9 && digit >= 0)
        {
            // using the digits defined above
            for (int y = 0; y < 5; y++)
            {
                for (int x = 0; x < 4; x++)
                {
                    if (digits[digit][y][x])
                    {
                        setLED(originX + x, originY + y);
                    }
                }
            }
        }
        else
        {
            Serial.println("Digit out of range");
        }
        
        
    };

    // auto-adjust the brightness
    void adjustBrightness()
    {
        if (autoBrightness)
        {
            int measVal = analogRead(brightnessPin);
            Serial.println(measVal);
            brightness = measVal * 10.0 / 4096.0;
            // TODO: scale the measured value to an appropriate brightness factor
        }
    };

public:
    /// Constructor
    /// @param dataPin Pin to which the LED strip is connected
    /// @param brightnessPin Pin to which the brightness sensor is connected
    Display(int brightnessPin)
    : brightnessPin(brightnessPin){};

    /// initialize the display
    void begin()
    {
#ifndef virtual
        FastLED.addLeds<WS2811, dataPin, RGB>(leds, NUM_LEDS);
#endif
        pinMode(brightnessPin, INPUT);
    };

    /// display the time in words
    /// @param hour the current hour
    /// @param minute the current minute
    void displayTime(int hour, int minute)
    {
        FastLED.clear();

        setLEDs(displayWords[ES]);
        setLEDs(displayWords[IST]);

        // set hour - any given hour display starts 25 min before the full hour and ends half an hour after
        int displayHour;
    
        if (hour==12 && (minute >= 25))
        {
            displayHour = 1;
        }
        else
        {
            displayHour = hour + (minute >= 25);
        }

        setLEDs(displayNumbers[displayHour]);

        // set minute display in 5 minute steps
        switch (minute / 5)
        {
        case 0:
            if(displayHour==1)                      //Es ist EIN Uhr, statt EINS Uhr
            {
                FastLED.clear();

                setLEDs(displayWords[ES]);
                setLEDs(displayWords[IST]);

                setLEDs(displayGroup(5, 2, 4));
            }
            setLEDs(displayWords[UHR]);
            break;
        case 1:
            setLEDs(displayWords[FUENF]);
            setLEDs(displayWords[NACH]);
            break;
        case 2:
            setLEDs(displayWords[ZEHN]);
            setLEDs(displayWords[NACH]);
            break;
        case 3:
            setLEDs(displayWords[VIERTEL]);
            setLEDs(displayWords[NACH]);
            break;
        case 4:
            setLEDs(displayWords[ZWANZIG]);
            setLEDs(displayWords[NACH]);
            break;
        case 5:
            setLEDs(displayWords[FUENF]);
            setLEDs(displayWords[VOR]);
            setLEDs(displayWords[HALB]);
            break;
        case 6:
            setLEDs(displayWords[HALB]);
            break;
        case 7:
            setLEDs(displayWords[FUENF]);
            setLEDs(displayWords[NACH]);
            setLEDs(displayWords[HALB]);
            break;
        case 8:
            setLEDs(displayWords[ZWANZIG]);
            setLEDs(displayWords[VOR]);
            break;
        case 9:
            setLEDs(displayWords[VIERTEL]);
            setLEDs(displayWords[VOR]);
            break;
        case 10:
            setLEDs(displayWords[ZEHN]);
            setLEDs(displayWords[VOR]);
            break;
        case 11:
            setLEDs(displayWords[FUENF]);
            setLEDs(displayWords[VOR]);
            break;
        }

        // set residual display (the 4 bars underneath the word map)
        int restMinute = minute % 5;
        setLEDs(10, 0, restMinute - 1);

        displayStatus();

#ifndef virtual // for testing without the hardware
        FastLED.show();
#endif
    };

    /// Display an environmental value as a number, using the LED Grid as pixels
    /// @param value display value - must not be more than 99
    /// @param in whether to display "in" (for inside value)
    /// @param unit unit to display - can be 'C' or 'H'
    void displayVal(int value, bool in, char unit)
    {
        FastLED.clear();

        if (in)
        {
            // display "IN" (inside)
            setLED(3, 0);
            setLED(3, 1);
        }

        switch (unit)
        {
        case 'c':
        case 'C':
            setLED(10, 6);
            break;

        case 'h':
        case 'H':
            setLED(10, 3);
            break;
        }

        // display only values up to 99
        if (value < 99 and value > -99)
        {
            // display "ne" for negative numbers
            if (value < 0) 
            {
                setLED(9,0);
                setLED(9,1);
            }
            displayDigit(abs(value) / 10, 0, 2);
            displayDigit(abs(value) % 10, 5, 2);
        }

        displayStatus();

    #ifndef virtual // for testing without the hardware
        FastLED.show();
    #endif
    };

    /// @brief Set the online status to display
    /// @param status New status
    void setOnlineStatus(bool status)
    {
        online = status;
    };

    /// @brief Set the "setting mode" (display is flashing)
    /// @param settingMode whether the setting mode is active
    void setSettingMode(bool settingMode)
    {
        this->settingMode = settingMode;
    };

    /// @brief Activate auto brightness
    void setAutoBrightness()
    {
        autoBrightness = true;
    };

    /// @brief Manually cycle through brightness vales - this disables auto brightness
    void changeBrightness()
    {
        autoBrightness = false;
        brightness = ((int)(brightness + 1) % 10);
        Serial.print("brightness = ");
        Serial.println((colors[colorIndex] / (10.0 / (double)(brightness + 1))).r);
    };

    /// @brief Cycle through display colors
    void changeColor()
    {
        colorIndex = (int)(colorIndex + 1) % 8;
    };
};

#endif // SPE_CLOCK_DISPL_H