#include <Arduino.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <Preferences.h>
#include <WiFi.h>
#include <string.h>
#include <DNSServer.h>

#include "OpenWeatherMap.h"

// html string for the web interface
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML>
<html>
<head>
  <title>Word Clock Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    html {font-family: Arial; display: inline-block; text-align: center;}
    form {border: 3px solid #f1f1f1; border-radius: 15px; padding: 20px; max-width: 400px; margin: auto;}
    input[type=text], input[type=password] {width: 100%; padding: 12px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; box-sizing: border-box;}
    input:invalid {background-color: #ff9f9fff;}
    button {background-color: #4CAF50; color: white; padding: 14px 20px; margin: 8px 0; border: none; cursor: pointer; width: 100%;}
    button:hover {opacity: 0.8;}
  </style>
</head>
<body>
  <h2>Word Clock Setup</h2>
  <form action="/save" method="POST">
    <div>
	  <h3>WiFi Zugangsdaten</h3>
      <label for="ssid">WiFi SSID:</label><br>
      <input type="text" id="ssid" name="ssid"><br>
      <label for="password">WiFi Passwort:</label><br>
      <input type="password" id="password" name="password"><br>
      <button type="submit">Speichern und Verbinden</button>
    </div>
  </form>
  <form action="/save" method="POST">
    <div>
      <label for="apiKey">OpenWeatherMap API key:</label><br>
      <input type="text" id="apiKey" name="apiKey" pattern="[0-9a-f]{32}"><br>
      <button type="submit">Speichern</button>
    </div>
  </form>  
  <form action="/save" method="POST">
    <div>
      <label for="zipCode">Postleitzahl,Land (z.B. 76178,DE):</label><br>
      <input type="text" id="zipCode" name="zipCode" pattern="\w+,[A-Z]{2}"><br>
      <button type="submit">Speichern</button>
    </div>
  </form>
</body>
</html>
)rawliteral";

/// web interface for the world clock, allows input of WiFi credentials and OWM API data
class Webinterface
{
private:
    // for displaying the interface
    AsyncWebServer server;

    // DNS Server to create a captive portal
    DNSServer dns;

    // persistent storage of entered settings
    Preferences preferences;

    // pointer to OWM object - this is used to 
    OpenWeatherMap &owm;

    // client mode wifi credentials
    const char *client_ssid = nullptr;
    const char *client_password = nullptr;
    // ap mode wifi credentials
    const char *ap_ssid;
    const char *ap_password;

    // whether the ESP is running in AP mode
    bool apMode = false;

    // IP address of the ESP in AP mode
    const IPAddress apIP;

    /// @brief handles a web request with config data
    /// @param request 
    void handleDataEntry(AsyncWebServerRequest *request);

public:
    /// @brief Constructor for the web interface class
    /// @param owm_instance pointer to a OWM object - this is used for setting the API key and location
    /// @param ap_ssid WiFi SSID in AP mode
    /// @param ap_password WiFi password in AP mode
    Webinterface(OpenWeatherMap &owm_instance, const char *ap_ssid, const char *ap_password);

    /// @brief Sets up the web interface and starts handling requests
    void begin();

    /// @brief Sets up the web interface and starts handling requests
    /// @param ap_mode pre-set AP mode
    /// @param clear wether to clear the previous configs - this is only evaluated in AP mode
    void begin(bool ap_mode, bool clear);

    /// @brief clear all previously set configs
    void clear();

    /// @brief handle new DNS requests - this needs to be called periodically
    void update();

    /// @brief returns wether the ESP is in online mode (i.e connected to an external WiFi network)
    /// @returns wether the ESP is in online mode
    bool getOnlineMode();
};

inline void Webinterface::handleDataEntry(AsyncWebServerRequest *request)
{
    if (request->hasParam("ssid", true))
    {
        String ssid = request->getParam("ssid", true)->value();
        // if no password is given in the request, it is set as an empty string
        String password = "";
        if (request->hasParam("password", true))
        {
            password = request->getParam("password", true)->value();
        }

        // Save credentials
        preferences.putString("ssid", ssid);
        preferences.putString("password", password);

        Serial.println(ssid);
        Serial.println(password);

        // Update const char* pointers
        client_ssid = ssid.c_str();
        client_password = password.c_str();

        // respond with a success message
        request->send(200, "text/plain", "Input saved.");

        // Reset flag and try to connect
        apMode = false;
        begin();
    }
    else
    {
        if (request->hasParam("apiKey", true))
            {
                String apiKey = request->getParam("apiKey", true)->value();
                owm.setAPIKey(apiKey.c_str());
                preferences.putString("apiKey", apiKey);
            }

        if (request->hasParam("zipCode", true))
            {
                String zipCode = request->getParam("zipCode", true)->value();
                owm.setByZipCode(zipCode.c_str());
                preferences.putString("zipCode", zipCode);
            }
        request->send(200, "text/plain", "Input saved.");
    }

}

Webinterface::Webinterface(OpenWeatherMap &owm_instance, const char *ap_ssid, const char *ap_password)
    : server(80), owm(owm_instance), ap_ssid(ap_ssid), ap_password(ap_password), apIP(192, 168, 4, 1)
{
}

inline void Webinterface::begin()
{
    begin(false, false);
}

inline void Webinterface::begin(bool ap_mode, bool clear)
{
    preferences.begin("wifi-config", false);

    // Get stored WiFi credentials
    String tempSSID = preferences.getString("ssid", "");
    String tempPassword = preferences.getString("password", "");

    if (!ap_mode && tempSSID.length() > 0)
    {
        // connect to an existing WiFi network
        this->apMode = false;
        client_ssid = tempSSID.c_str();
        client_password = tempPassword.c_str();
        Serial.println("Found stored credentials");
        Serial.print(client_ssid);
        Serial.print("; ");
        Serial.println(client_password);

        WiFi.begin(client_ssid, client_password);
        Serial.println("Connecting Wifi");
        int tries = 0;
        while (WiFi.status() != WL_CONNECTED)
        {
            Serial.print(".");
            delay(500);

            tries++;
            // abort after 30 seconds
            if (tries > 60)
                break;
        }

        if (WiFi.status() != WL_CONNECTED)
        {
            // if the connection was aborted, change to AP mode
            WiFi.disconnect();
            this->apMode = true;

            WiFi.mode(WIFI_AP);
            WiFi.softAPConfig(apIP, apIP, IPAddress(255, 255, 255, 0));
            WiFi.softAP(ap_ssid, ap_password);
            Serial.println("Connection failed. Switching to AP mode");

            // start dns server for a captive portal
            dns.start(53, "*", apIP);
        }

        Serial.println(WiFi.localIP());
    }
    else
    {
        // start up in AP mode
        this->apMode = true;
        // if apMode AND clear are set, clear all stored preferences
        if (clear)
            preferences.clear();
        WiFi.mode(WIFI_AP);
        WiFi.softAPConfig(apIP, apIP, IPAddress(255, 255, 255, 0));
        WiFi.softAP(ap_ssid, ap_password);
        Serial.println("No stored credentials found");

        dns.start(53, "*", apIP);
    }

    // get the OWM config from storage and set them in the OWM object
    String apiKey = preferences.getString("apiKey", "");
    String zipCode = preferences.getString("zipCode", "");

    if (apiKey.length() > 0)
    {
        owm.setAPIKey(apiKey.c_str());
    }

    if (zipCode.length() > 0)
    {
        owm.setByZipCode(zipCode.c_str());
    }
    
    // set up handling of web requests
    server.onNotFound([](AsyncWebServerRequest *request)
              { request->send_P(200, "text/html", index_html); });
    server.on("/save", HTTP_POST, [this](AsyncWebServerRequest *request)
              { this->handleDataEntry(request); });

    server.begin();
}

inline void Webinterface::clear()
{
    preferences.clear();
}

inline void Webinterface::update()
{
    dns.processNextRequest();
}

inline bool Webinterface::getOnlineMode()
{
    return !apMode;
}
