#ifndef SPE_CLOCK_H
#define SPE_CLOCK_H

#include <Arduino.h>
#include <ESP32Time.h>
#include <time.h>

class Clock {
private:
    /// Whether the time is set manually
    bool manualSet;
    /// RTC object
    ESP32Time rtc;
    /// time of the last NTP update
    long updateTime;


public:
    /**
     * Constructor
     *
     * @param manualSet Whether the time is set manually
     */
    explicit Clock(bool manualSet);

    /**
     * Sets the current time to the given value
     *
     * @param hour the hour to set
     * @param minute the minute to set
     * @param second the second to set
     */
    void setTime(int hour, int minute, int second);

    /// update local time from NTP server
    void setNTPTime();

    /*
    *   Increments the current hour and sets the clock to manual mode 
    */
    void incHour();

    /*
    *   Increments the current minute and sets the clock to manual mode 
    */
    void incMinute();

    /*
    *   Returns the current hour
    */
   int getHour();    
   
   /*
    *   Returns the current minute
    */
   int getMinute();


};


#endif //SPE_CLOCK_H
