
#include <EventButton.h>
#include <WiFi.h>
#include <DHT.h>

#include "Clock.h"
#include "Display.h"
#include "OpenWeatherMap.h"
#include "Webinterface.h"

// hardware pins
#define MODE_BUTTON_PIN D3
#define COLOR_BUTTON_PIN D5
#define BRIGHTNESS_BUTTON_PIN D4

#define LED_DATA_PIN 5
#define BRIGHTNESS_PIN A0

#define DHT_PIN D8

// WiFi credentials to use in AP mode
const char *ssid = "SPE_WordClock";
const char *pw = "";

// objects for various functions of the clock
Clock cl(false);
Display<LED_DATA_PIN> display(BRIGHTNESS_PIN);
OpenWeatherMap owm;
Webinterface webint(owm, ssid, pw);

// DHT11 temperature/humidity sensor
DHT dht11(DHT_PIN, DHT11);

// time variables to track time since the last update/action
unsigned long int lastUpdate = 0;
unsigned long int lastSettingAction;

// whether the clock is in setting mode
bool settingMode = false;

// current mode:
// 0 - clock
// 1 - local temperature
// 2 - local humidity
// 3 - OWM temperature
// 4 - OWM humidity
unsigned int mode = 0;

// functions to handle button presses
void onModeClick(InputEventType et, EventButton &eb);
void onColorClick(InputEventType et, EventButton &eb);
void onBrightnessClick(InputEventType et, EventButton &eb);

// objects for button interface
EventButton modeButton(MODE_BUTTON_PIN);
EventButton colorButton(COLOR_BUTTON_PIN);
EventButton brightnessButton(BRIGHTNESS_BUTTON_PIN);

// setup function - this is run once at startup
void setup()
{
    // set up serial communication and wait to establish the connection
    Serial.begin(115200);
    delay(1000);

    dht11.begin();

    // start handling button inputs
    modeButton.setPressedState(true);
    colorButton.setPressedState(true);
    brightnessButton.setPressedState(true);
    modeButton.begin();
    colorButton.begin();
    brightnessButton.begin();

    // start the webinterface
    webint.begin(modeButton.isPressed(), brightnessButton.isPressed());

    // start the display
    display.begin();

    // set the time via NPT (if available)
    cl.setNTPTime();

    // configure button interface
    modeButton.setCallback(onModeClick);
    modeButton.enableLongPressRepeat(false);
    colorButton.setCallback(onColorClick);
    brightnessButton.setCallback(onBrightnessClick);
}

void loop()
{
    if (millis() - lastUpdate > 100)
    {
        // update every 100 ms (could probably be slower)
        lastUpdate = millis();
        switch (mode)
        {
        case 0: // clock
            display.displayTime(cl.getHour(), cl.getMinute());
            break;

        case 1: // local temperature
            Serial.println((int)dht11.readTemperature());
            display.displayVal((int)dht11.readTemperature(), true, 'C');
            break;

        case 2: // local humidity
            Serial.println((int)dht11.readHumidity());
            display.displayVal((int)dht11.readHumidity(), true, 'H');
            break;

        case 3: // global temperature
            // return to clock mode if the ESP is offline
            if(!webint.getOnlineMode()) mode = 0;
            owm.update();
            Serial.println(owm.getTemperature());
            display.displayVal(owm.getTemperature(), false, 'C');
            break;

        case 4: // global humidity
            // return to clock mode if the ESP is offline
            if(!webint.getOnlineMode()) mode = 0;
            owm.update();
            Serial.println(owm.getHumidity());
            display.displayVal(owm.getHumidity(), false, 'H');
            break;

        default:
            break;
        }
        display.setOnlineStatus(webint.getOnlineMode());
    }

    // turn off setting mode if the last setting action was more than 10 s ago
    if (settingMode && millis() - lastSettingAction > 10000)
    {
        display.setSettingMode(false);
        settingMode = false;
        Serial.println("disable clock setting mode");
    }

    // handle DNS requests
    webint.update();


    // handle button inputs
    modeButton.update();
    colorButton.update();
    brightnessButton.update();
}

// callback function to handle mode button presses
void onModeClick(InputEventType et, EventButton &eb)
{
    if (et == InputEventType::CLICKED)
    {
        if (settingMode)
        {
            // a short press of the mode button disables setting mode
            display.setSettingMode(false);
            settingMode = false;
            Serial.println("disable clock setting mode");
            lastUpdate = 0; // refresh display immediately
        }
        else
        {
            // cycle through the modes 0-4
            mode = (mode + 1) % 5;
            lastUpdate = 0; // refresh display immediately
            Serial.print("mode: ");
            Serial.println(mode);
        }
    }
    else if (et == InputEventType::LONG_PRESS)
    {
        // enable clock setting if in clock mode
        if (mode == 0)
        {
            display.setSettingMode(true);
            settingMode = true;
            lastSettingAction = millis();
            Serial.println("enable clock setting mode");
            lastUpdate = 0; // refresh display immediately
        }
    }
}

// callback function to handle color button presses
void onColorClick(InputEventType et, EventButton &eb)
{
    if (et == InputEventType::CLICKED)
    {
        if (settingMode)
        {
            // increment the hour value if in setting mode
            cl.incHour();
            lastSettingAction = millis();
            Serial.println("hour++");
        }
        else
        {
            // cycle through colors
            display.changeColor();
        }
        lastUpdate = 0; // refresh display immediately
    }
}

void onBrightnessClick(InputEventType et, EventButton &eb)
{
    if (et == InputEventType::CLICKED)
    {
        if (settingMode)
        {
            // increment the hour value if in setting mode
            cl.incMinute();
            lastSettingAction = millis();
            Serial.println("minute++");
        }
        else
        {
            // cycle through brightnesses
            display.changeBrightness();
        }
        lastUpdate = 0; // refresh display immediately
    }
    else if (et == InputEventType::LONG_PRESS)
    {
        if (settingMode)
        {
            // increment the hour value if in setting mode
            cl.incMinute();
            lastSettingAction = millis();
            Serial.println("minute++");
        }
        else
        {
            // enable auto brightness
            display.setAutoBrightness();
            Serial.println("auto brightness enabled");
        }
        lastUpdate = 0; // refresh display immediately
        // enable auto brightness
    }
}
